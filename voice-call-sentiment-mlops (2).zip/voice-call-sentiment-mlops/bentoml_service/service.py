import bentoml
from pydantic import BaseModel
import joblib

class Request(BaseModel):
    transcript: str

svc = bentoml.Service("voice_call_sentiment_service")
model = joblib.load("models/model.joblib")

@svc.api(input=bentoml.io.JSON(pydantic_model=Request), output=bentoml.io.JSON())
def predict(request: Request):
    sentiment = model.predict([request.transcript])[0]
    probability = max(model.predict_proba([request.transcript])[0]) if hasattr(model, "predict_proba") else 0.0
    risk_map = {"positive": "low", "neutral": "medium", "negative": "high"}
    return {
        "sentiment": sentiment,
        "confidence": round(float(probability), 4),
        "escalation_risk": risk_map.get(sentiment, "medium")
    }

@svc.api(input=bentoml.io.JSON(), output=bentoml.io.JSON())
def health(_: dict):
    return {"status": "ok", "service": "voice_call_sentiment_service"}
