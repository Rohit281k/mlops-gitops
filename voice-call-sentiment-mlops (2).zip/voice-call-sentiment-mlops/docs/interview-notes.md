# Interview Notes

## One-minute explanation

I built a production-grade MLOps platform for voice call sentiment and escalation risk prediction. The system versions call transcript datasets using DVC and lakeFS, validates incoming data using Great Expectations-style checks, stores reusable features in Feast, trains models through Kubeflow Pipelines, tracks experiments and versions models using MLflow and MLflow Registry, packages the model with BentoML, and deploys it as a REST inference service using Docker, Kubernetes and KServe. For production readiness, I added HPA autoscaling, Argo CD GitOps deployment, Prometheus/Grafana dashboards, and drift monitoring with Evidently and NannyML.

## Tools explanation

- DVC: versioned ML pipeline and datasets.
- lakeFS: Git-like data lake branching and commits.
- Great Expectations: data quality gates before training.
- Feast: consistent feature definitions for training and serving.
- MLflow: experiment tracking and model registry.
- Kubeflow: pipeline orchestration.
- Katib: hyperparameter tuning.
- BentoML: API packaging.
- KServe: Kubernetes-native inference serving.
- HPA: autoscaling inference pods.
- Evidently/NannyML: drift and performance monitoring.
- Prometheus/Grafana: service and infrastructure observability.
- Argo CD: GitOps deployment.
