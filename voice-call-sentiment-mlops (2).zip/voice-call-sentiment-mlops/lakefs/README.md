# lakeFS setup notes

Use lakeFS to version raw and processed datasets like Git branches.

Suggested branches:

```text
main
experiment/sentiment-v1
experiment/drift-test
production-approved-data
```

Example workflow:

```bash
lakectl repo create lakefs://voice-call-sentiment s3://your-bucket/voice-call-sentiment
lakectl branch create lakefs://voice-call-sentiment/experiment/sentiment-v1 --source lakefs://voice-call-sentiment/main
lakectl fs upload lakefs://voice-call-sentiment/experiment/sentiment-v1/raw/call_transcripts.csv -s data/raw/call_transcripts.csv
lakectl commit lakefs://voice-call-sentiment/experiment/sentiment-v1 -m "add initial call transcript dataset"
lakectl merge lakefs://voice-call-sentiment/experiment/sentiment-v1 lakefs://voice-call-sentiment/main
```
