from kfp import dsl

@dsl.component(base_image="python:3.11")
def validate_data():
    import subprocess
    subprocess.run(["python", "src/data_validation/validate_data.py"], check=True)

@dsl.component(base_image="python:3.11")
def train_model():
    import subprocess
    subprocess.run(["python", "src/training/train.py"], check=True)

@dsl.component(base_image="python:3.11")
def drift_report():
    import subprocess
    subprocess.run(["python", "src/monitoring/evidently_report.py"], check=True)

@dsl.pipeline(name="voice-call-sentiment-training-pipeline")
def pipeline():
    validation = validate_data()
    training = train_model().after(validation)
    drift_report().after(training)
