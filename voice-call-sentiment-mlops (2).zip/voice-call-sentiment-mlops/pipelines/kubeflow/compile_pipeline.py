from kfp import compiler
from pipeline import pipeline

compiler.Compiler().compile(
    pipeline_func=pipeline,
    package_path="pipelines/kubeflow/voice_call_sentiment_pipeline.yaml"
)
print("Pipeline compiled: pipelines/kubeflow/voice_call_sentiment_pipeline.yaml")
