import joblib

MODEL_PATH = "models/model.joblib"
model = joblib.load(MODEL_PATH)

def predict(transcript: str):
    sentiment = model.predict([transcript])[0]
    proba = max(model.predict_proba([transcript])[0]) if hasattr(model, "predict_proba") else None
    risk_map = {"positive": "low", "neutral": "medium", "negative": "high"}
    return {
        "sentiment": sentiment,
        "confidence": round(float(proba), 4) if proba else None,
        "escalation_risk": risk_map.get(sentiment, "medium")
    }
