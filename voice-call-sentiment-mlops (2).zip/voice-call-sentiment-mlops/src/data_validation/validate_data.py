import os
import json
import pandas as pd

TRAIN_PATH = "data/processed/train.csv"
REPORT_PATH = "reports/data_validation_report.json"

required_columns = [
    "call_id", "transcript", "sentiment", "escalation_risk",
    "call_duration_sec", "silence_ratio", "agent_talk_ratio"
]
allowed_sentiments = {"positive", "neutral", "negative"}
allowed_risks = {"low", "medium", "high"}

df = pd.read_csv(TRAIN_PATH)
checks = {
    "required_columns_present": all(c in df.columns for c in required_columns),
    "no_null_transcripts": df["transcript"].notna().all(),
    "sentiment_values_valid": set(df["sentiment"].unique()).issubset(allowed_sentiments),
    "risk_values_valid": set(df["escalation_risk"].unique()).issubset(allowed_risks),
    "call_duration_positive": (df["call_duration_sec"] > 0).all(),
    "silence_ratio_between_0_and_1": df["silence_ratio"].between(0, 1).all(),
    "agent_talk_ratio_between_0_and_1": df["agent_talk_ratio"].between(0, 1).all(),
}
report = {"success": all(checks.values()), "checks": checks, "row_count": int(len(df))}
os.makedirs("reports", exist_ok=True)
with open(REPORT_PATH, "w") as f:
    json.dump(report, f, indent=2)
if not report["success"]:
    raise ValueError(f"Data validation failed: {report}")
print(json.dumps(report, indent=2))
