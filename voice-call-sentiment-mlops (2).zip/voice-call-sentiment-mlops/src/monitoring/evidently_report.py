import os
import pandas as pd

try:
    from evidently.report import Report
    from evidently.metric_preset import DataDriftPreset, TargetDriftPreset
except Exception:
    Report = None

os.makedirs("reports", exist_ok=True)
ref = pd.read_csv("data/processed/train.csv")
cur = pd.read_csv("data/processed/test.csv")

if Report:
    report = Report(metrics=[DataDriftPreset(), TargetDriftPreset()])
    report.run(reference_data=ref, current_data=cur)
    report.save_html("reports/evidently_report.html")
else:
    with open("reports/evidently_report.html", "w") as f:
        f.write("<html><body><h1>Evidently report placeholder</h1></body></html>")
print("Saved reports/evidently_report.html")
