import os
import json
import pandas as pd

os.makedirs("reports", exist_ok=True)
train = pd.read_csv("data/processed/train.csv")
test = pd.read_csv("data/processed/test.csv")

# Lightweight monitoring summary. Replace with NannyML CBPE/DLE when probability columns are available.
summary = {
    "reference_rows": int(len(train)),
    "current_rows": int(len(test)),
    "reference_sentiment_distribution": train["sentiment"].value_counts(normalize=True).round(4).to_dict(),
    "current_sentiment_distribution": test["sentiment"].value_counts(normalize=True).round(4).to_dict(),
    "monitoring_tool": "NannyML-ready placeholder for realised performance and estimated performance monitoring"
}
with open("reports/nannyml_monitoring_summary.json", "w") as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
