import os
import json
import yaml
import joblib
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, classification_report

with open("params.yaml") as f:
    params = yaml.safe_load(f)

train = pd.read_csv(params["data"]["train_path"])
test = pd.read_csv(params["data"]["test_path"])

X_train, y_train = train["transcript"], train["sentiment"]
X_test, y_test = test["transcript"], test["sentiment"]

pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(
        max_features=params["model"]["max_features"],
        ngram_range=(params["model"]["ngram_min"], params["model"]["ngram_max"])
    )),
    ("clf", LogisticRegression(max_iter=1000, random_state=params["model"]["random_state"]))
])

mlflow.set_experiment(params["mlflow"]["experiment_name"])
with mlflow.start_run():
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_test)
    acc = accuracy_score(y_test, preds)
    f1 = f1_score(y_test, preds, average="weighted")

    mlflow.log_params(params["model"])
    mlflow.log_metric("accuracy", acc)
    mlflow.log_metric("weighted_f1", f1)
    mlflow.sklearn.log_model(
        pipeline,
        artifact_path="model",
        registered_model_name=params["mlflow"]["registered_model_name"]
    )

os.makedirs("models", exist_ok=True)
os.makedirs("reports", exist_ok=True)
joblib.dump(pipeline, "models/model.joblib")
metrics = {"accuracy": acc, "weighted_f1": f1}
with open("reports/metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)
with open("models/metadata.json", "w") as f:
    json.dump({"model_name": params["mlflow"]["registered_model_name"], **metrics}, f, indent=2)
print(json.dumps(metrics, indent=2))
print(classification_report(y_test, preds))
