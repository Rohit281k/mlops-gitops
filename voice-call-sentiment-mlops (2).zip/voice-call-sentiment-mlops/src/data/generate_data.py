import os
import random
import pandas as pd
from sklearn.model_selection import train_test_split

random.seed(42)

positive = [
    "customer is happy with call quality and appreciates quick resolution",
    "agent solved the issue quickly and customer thanked the support team",
    "customer liked recording quality and said everything works fine",
]
neutral = [
    "customer asked about account settings and call recording configuration",
    "agent explained the dashboard usage and shared next steps",
    "customer requested information about retention policy and export options",
]
negative = [
    "customer is angry because recording failed and wants refund immediately",
    "customer complained about repeated call drops and poor support response",
    "customer is frustrated due to missing transcript and escalation delay",
]

rows = []
for i in range(600):
    label = random.choice(["positive", "neutral", "negative"])
    if label == "positive":
        text = random.choice(positive)
        risk = "low"
    elif label == "neutral":
        text = random.choice(neutral)
        risk = "medium"
    else:
        text = random.choice(negative)
        risk = "high"
    rows.append({
        "call_id": f"CALL-{i:05d}",
        "transcript": text,
        "sentiment": label,
        "escalation_risk": risk,
        "call_duration_sec": random.randint(60, 1800),
        "silence_ratio": round(random.uniform(0.01, 0.45), 3),
        "agent_talk_ratio": round(random.uniform(0.35, 0.75), 3),
    })

os.makedirs("data/raw", exist_ok=True)
os.makedirs("data/processed", exist_ok=True)
df = pd.DataFrame(rows)
df.to_csv("data/raw/call_transcripts.csv", index=False)
train, test = train_test_split(df, test_size=0.2, random_state=42, stratify=df["sentiment"])
train.to_csv("data/processed/train.csv", index=False)
test.to_csv("data/processed/test.csv", index=False)
print("Generated data/raw/call_transcripts.csv, data/processed/train.csv, data/processed/test.csv")
