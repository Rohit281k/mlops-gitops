# Voice Call Sentiment & Escalation Risk Analyzer — Production MLOps Project

Production-grade MLOps project for analysing customer call transcripts and predicting:

1. Sentiment: `positive`, `neutral`, `negative`
2. Escalation risk: `low`, `medium`, `high`
3. Operational metrics: latency, error rate, drift and retraining signals

This project is designed for MLOps Engineer interviews and demonstrates:

- DVC for data/model pipeline versioning
- lakeFS for data lake versioning
- Great Expectations for data quality checks
- Feast for feature store
- MLflow Tracking and MLflow Model Registry
- Kubeflow Pipelines for training workflow
- Katib for hyperparameter tuning
- BentoML for model packaging
- Docker for containerisation
- Kubernetes, KServe and HPA for model serving and autoscaling
- Evidently and NannyML for drift/performance monitoring
- Prometheus and Grafana for infra/API monitoring
- Argo CD for GitOps deployment

---

## Architecture

```text
Raw Call Transcripts
        |
        v
lakeFS Repository + DVC Dataset Versioning
        |
        v
Great Expectations Validation
        |
        v
Feature Engineering
        |
        v
Feast Feature Store
        |
        v
Kubeflow Training Pipeline
        |
        v
Katib Hyperparameter Tuning
        |
        v
MLflow Tracking + MLflow Model Registry
        |
        v
BentoML Model Service
        |
        v
Docker Image
        |
        v
KServe on Kubernetes
        |
        v
HPA Autoscaling
        |
        v
Prometheus + Grafana + Evidently + NannyML
        |
        v
Retraining Trigger
```

---

## Local quick start

```bash
git clone <your-repo-url>
cd voice-call-sentiment-mlops
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make data
make validate
make train
make serve-local
```

Test API:

```bash
curl -X POST http://127.0.0.1:3000/predict \
  -H 'Content-Type: application/json' \
  -d '{"transcript":"customer is angry and wants refund because call recording failed multiple times"}'
```

---

## DVC pipeline

```bash
dvc init
dvc repro
dvc dag
```

Stages are defined in `dvc.yaml`:

1. Generate synthetic call data
2. Validate data using Great Expectations-style checks
3. Train model and log to MLflow
4. Run drift report

---

## MLflow

Start MLflow locally:

```bash
mlflow ui --host 0.0.0.0 --port 5000
```

Training logs:

- parameters
- accuracy
- F1 score
- model artifact
- registered model name: `voice_call_sentiment_model`

---

## BentoML

Build and serve locally:

```bash
bentoml serve bentoml_service.service:svc --reload --port 3000
```

Build container:

```bash
bentoml build
bentoml containerize voice_call_sentiment_service:latest
```

---

## Kubernetes deployment

```bash
kubectl create namespace mlops || true
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/hpa.yaml
```

Check:

```bash
kubectl get pods -n mlops
kubectl get svc -n mlops
kubectl get hpa -n mlops
```

---

## KServe deployment

```bash
kubectl apply -f k8s/kserve-inferenceservice.yaml
kubectl get inferenceservice -n mlops
```

---

## Kubeflow pipeline

Compile pipeline:

```bash
python pipelines/kubeflow/compile_pipeline.py
```

This creates:

```text
pipelines/kubeflow/voice_call_sentiment_pipeline.yaml
```

Upload it to Kubeflow Pipelines UI.

---

## Katib tuning

```bash
kubectl apply -f katib/experiment.yaml
kubectl get experiment -n kubeflow
```

---

## Monitoring

Prometheus scrape config:

```bash
kubectl apply -f monitoring/prometheus/prometheus-config.yaml
```

Grafana dashboard JSON:

```text
monitoring/grafana/voice-call-dashboard.json
```

Generate drift reports:

```bash
python src/monitoring/evidently_report.py
python src/monitoring/nannyml_monitor.py
```

---

## Argo CD GitOps

```bash
kubectl apply -f argocd/application.yaml
```

Argo CD watches Kubernetes manifests from Git and keeps the cluster in sync.

---

## Resume bullets

- Built a production-grade MLOps platform for voice call sentiment and escalation risk prediction using DVC, lakeFS, Feast, MLflow, Kubeflow, BentoML and KServe.
- Implemented automated data validation and reproducible training pipelines using Great Expectations-style checks, DVC pipelines and MLflow Tracking.
- Packaged the ML model using BentoML and deployed it as a REST API on Kubernetes with KServe and HPA-based autoscaling.
- Integrated Evidently and NannyML monitoring for data drift, prediction drift and model performance degradation.
- Configured Prometheus and Grafana dashboards for API latency, request count, error rate, pod health and inference monitoring.
- Used Argo CD for GitOps-based continuous deployment of model-serving Kubernetes manifests.

---

## Interview explanation

I built an end-to-end MLOps project for voice call sentiment and escalation risk prediction. Raw call transcripts are versioned using lakeFS and DVC, validated using Great Expectations-style checks, converted into features and reused through Feast. The model training workflow is automated using Kubeflow Pipelines, experiments are tracked in MLflow and production models are promoted through MLflow Model Registry. The selected model is packaged with BentoML, containerised using Docker and deployed on Kubernetes using KServe. I configured HPA for autoscaling, Prometheus and Grafana for infrastructure monitoring, and Evidently plus NannyML for drift detection and retraining signals.
