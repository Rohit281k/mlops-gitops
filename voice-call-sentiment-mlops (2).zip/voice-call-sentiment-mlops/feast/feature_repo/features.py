from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource
from feast.types import Float32, Int64

call = Entity(name="call_id", join_keys=["call_id"])

call_source = FileSource(
    path="../../data/processed/train.csv",
    timestamp_field=None,
)

call_features = FeatureView(
    name="call_features",
    entities=[call],
    ttl=timedelta(days=30),
    schema=[
        Field(name="call_duration_sec", dtype=Int64),
        Field(name="silence_ratio", dtype=Float32),
        Field(name="agent_talk_ratio", dtype=Float32),
    ],
    online=True,
    source=call_source,
)
